# AI Documentary Studio — Starter v1

This is a free, static Progressive Web App starter for Android browsers.

## Included
- Black-and-gold responsive interface
- Documentary outline templates in English, Urdu, Arabic and Hindi
- Phone/browser text-to-speech preview using voices already available on the device
- Save a project in this browser's local storage
- Export narration as a `.txt` file
- PWA manifest and service worker for install/offline shell

## Important limitations
- The outline generator is template-based, not an AI model.
- No real text-to-video model is connected yet.
- The 1,000,000 starter credits are display-only and do not represent usable compute.
- Browser speech voices vary by device and installed language packs.
- Saved projects are local to the browser/device; clearing browser data can remove them.

## Publish free with GitHub Pages
1. Create a **public** GitHub repository named `ai-documentary-studio`.
2. Upload all files in this folder to the repository root (not the ZIP file itself).
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main`, folder `/ (root)`, then Save.
6. Wait for the Pages URL to appear. Open it in Chrome on Android.
7. In Chrome, use the three-dot menu → **Install app** or **Add to Home screen**.

GitHub Pages on GitHub Free requires a public repository. Do not upload passwords, private API keys, personal documents, or private content.

## Next stage
Connect an AI script provider only if it offers a usable free tier without a payment method, then separately connect an available video-generation endpoint. Never put secret API keys in frontend JavaScript or a public repository.
